// telegramConfig.js

export const BOT_TOKEN = "8352146920:AAGiSvK4N9tmAGG-IVjR5uA18Ftl14bij9w";
export const CHAT_ID = "2058030255";
